Non-modal About dialog example
