Font chooser dialog example
