Custom dialog example
