Drawing curved lines example
