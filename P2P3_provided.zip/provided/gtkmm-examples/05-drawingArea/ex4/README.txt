Drawing arcs and circles example
