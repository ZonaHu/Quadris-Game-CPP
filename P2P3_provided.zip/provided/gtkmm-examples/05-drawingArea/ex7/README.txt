Custom clock widget example in Cairo
