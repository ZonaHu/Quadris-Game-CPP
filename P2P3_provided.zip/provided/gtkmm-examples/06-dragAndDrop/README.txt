Demonstrates drag-and-drop
