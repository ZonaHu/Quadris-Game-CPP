Code example taken from:

https://github.com/GNOME/gtkmm-documentation/tree/gtkmm-3-22/examples/book/application/command_line_handling

April 13, 2018
